<!DOCTYPE html>
<html lang="pl">
    <head>
        <meta charset="UTF-8">
        <title>Motocykle</title>
        <link rel="stylesheet" href="styl.css">
    </head>
    <body>
        <header class="baner">
            <h1>Motocykle - moja pasja</h1>
        </header>

        <img src="motor.png" alt="motocykl" class="zdjeciemotorpng">

        <main class="bloklewy">
            <h2>Gdzie pojechać?</h2>
            <?php
                $polaczenie = mysqli_connect("localhost", "root", "", "motory");
                $wynik = mysqli_query($polaczenie, 'SELECT nazwa, opis, poczatek, zdjecia.zrodlo FROM `wycieczki` JOIN zdjecia ON zdjecia.id = wycieczki.zdjecia_id');
                echo "<dl>";
                while ($row = mysqli_fetch_assoc($wynik)) {
                    echo "<dt>" . $row['nazwa'] . ", rozpoczyna się w " . $row['poczatek'] . ", ";
                    echo "<a href='" . $row['zrodlo'] . ".jpg" . "'>zobacz zdjęcie</a></dt>";
                    echo "<dd>" . $row['opis'] . "</dd>";
                }
                echo "</dl>";
            ?>
        </main>

        <aside class="blokiprawe">
            <h2>Co kupić?</h2>
            <ol>
                <li>Honda CBR125R</li>
                <li>Yamaha YBR125</li>
                <li>Honda VFR800i</li>
                <li>Honda CBR1100XX</li>
                <li>BMW R1200GS LC</li>
            </ol>
        </aside>

        <aside class="blokiprawe">
            <h2>Statystyki</h2>
            <?php
                $polaczenie2 = mysqli_connect("localhost", "root", "", "motory");
                $wynik2 = mysqli_query($polaczenie2, 'SELECT COUNT(id) AS liczba_wycieczek FROM wycieczki');

                $row = mysqli_fetch_assoc($wynik2);
                $liczba_wycieczek = $row['liczba_wycieczek'];

                echo "<p>Wpisanych wycieczek: $liczba_wycieczek</p>";

                mysqli_close($polaczenie2);
            ?>

            <p>Użytkowników forum: 200</p>
            <p>Przesłanych zdjęć: 1300</p>
        </aside>

        <footer class="stopka">
            <p>Stronę wykonał: 00000000000</p>
        </footer>
    </body>
</html>